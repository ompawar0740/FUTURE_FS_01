# 💼 Personal Professional Portfolio Website

A clean, responsive, and professional portfolio website built using HTML, CSS, and JavaScript.

This project was developed as part of **Future Interns – Full Stack Web Development Task 1 (2026)**.

It serves as a digital resume and personal brand website to showcase my skills, projects, and contact information.

---

## 🚀 Live Website

🔗 Live Link: https://your-live-link-here.netlify.app  
(Replace with your actual deployed link)

---

## 📌 Project Overview

This portfolio website includes:

- 🏠 Hero Section (Professional Introduction)
- 👨‍💻 About Me Section
- 🛠 Skills Section
- 🚀 Projects Section
- 📄 Resume Download Feature
- 📬 Contact Form (Frontend)
- 📱 Fully Responsive Design

The goal of this project was to build a recruiter-ready personal website that demonstrates frontend development skills and clean UI design.

---

## 🛠 Tech Stack Used

- HTML5
- CSS3
- JavaScript (Vanilla JS)
- Responsive Design (Media Queries)

No external frameworks were used in this basic version.

---

## 📂 Project Structure
portfolio/
│
├── index.html
├── style.css
├── script.js
├── resume.pdf
└── assets/
└── profile.jpg

## ✨ Features

- Clean and modern UI
- Mobile responsive layout
- Resume download button
- Interactive contact form (client-side)
- Structured sections for professional presentation
- SEO meta description included
